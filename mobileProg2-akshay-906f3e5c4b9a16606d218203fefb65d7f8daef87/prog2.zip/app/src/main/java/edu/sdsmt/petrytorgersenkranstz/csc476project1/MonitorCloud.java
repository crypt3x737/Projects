package edu.sdsmt.petrytorgersenkranstz.csc476project1;

import android.support.annotation.NonNull;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;


public class MonitorCloud {

    public final static MonitorCloud INSTANCE = new MonitorCloud();

    private static final String USER = "lolo";
    private static final String EMAIL = "lolo@gmail.com";
    private static final String PASSWORD = "lolzzzzz";
    private static final String TAG = "demonitor";
    private FirebaseAuth userAuth = FirebaseAuth.getInstance();
    private static FirebaseUser firebaseUser;
    private final DatabaseReference userRef = FirebaseDatabase.getInstance().getReference()
            .child("users").child(USER);
    /**
     * Set true if we want to cancel
     */
    private volatile boolean cancel = false;
    /**
     *  private to defeat instantiation.
     */

    private MonitorCloud() {
        createUser();
        checkConnection();
        startAuthListening();

    }

    private static boolean authenticated = false;
    private static boolean internet = false;

    public static boolean isAuthenicated(){
        return authenticated;
    }

    public static boolean isConnected() {
        return internet;
    }

    /**
     * Create a new user if possible
     */
    private void createUser() {

        userAuth.createUserWithEmailAndPassword(EMAIL, PASSWORD )
                .addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        firebaseUser = userAuth.getCurrentUser();
                        if(task.isSuccessful()  || firebaseUser != null) {
                            Log.d(TAG, "createUserWithEmail:onComplete:" + task.isSuccessful());
                            HashMap<String, Object> result = new HashMap<>();
                            result.put("id", firebaseUser.getUid());
                            result.put("password", PASSWORD);
                            result.put("email", EMAIL);
                            result.put("username", USER);
                            userRef.setValue(result);

                        }
                        else if(firebaseUser==null)
                        {
                            signIn();
                        }
                        else{
                            authenticated=false;
                        }

                    }

                });
    }

    /**
     * Monitors if we are connected to the internet
     */
    private void checkConnection() {

        DatabaseReference connectedRef = FirebaseDatabase.getInstance().getReference(".info/connected");

        connectedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                boolean connected = snapshot.getValue(Boolean.class);

                if (connected) {
                    Log.d(TAG, "have internet");
                    internet = true;
                }else
                {
                    Log.d(TAG, "do NOT have internet");
                    internet = false;

                    //the time out on the server for wifi lost is pretty long ( upto 5 min!)
                    //this forces a recheck much sooner
                    FirebaseDatabase.getInstance().goOnline();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                internet = false;
            }
        });
    }

    /**
     * Starts up a thread to monitor when a user is authenticated or not
     */
    private void startAuthListening() {
        userAuth.addAuthStateListener(new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                firebaseUser = firebaseAuth.getCurrentUser();
                if ( firebaseUser != null) {

                    // User is signed in
                    authenticated = true;
                    Log.d(TAG, "onAuthStateChanged:signed_in:" +  firebaseUser.getUid());
                } else {

                    // User is signed out
                    authenticated = false;
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                }
            }
        });

    }

    /**
     * Sign a user in with the given email and password
     */
    private void signIn() {
        // use "username" already exists
        userAuth.signInWithEmailAndPassword(EMAIL, PASSWORD)
                .addOnCompleteListener(new OnCompleteListener() {

                    @Override
                    public void onComplete(@NonNull Task task) {
                        if(task.isSuccessful()) {
                            Log.d(TAG, "signInWithEmail:onComplete:" + task.isSuccessful());
                            authenticated = true;

                        }else {
                            Log.w(TAG, "signInWithEmail:failed", task.getException());
                            authenticated = false;
                        }
                    }
                });
    }

    public static String getUserUid(){
        //stop people from getting the Uid if not logged in
        if(firebaseUser == null)
            return "";
        else
            return firebaseUser.getUid();
    }
}
