package edu.sdsmt.petrytorgersenkranstz.csc476project1;

import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;



public class Cloud {

    private static final String USER = "mobdevsdsmt";
    private static final String PASSWORD = "collegeisexpensive";
    private static DatabaseReference database = FirebaseDatabase.getInstance().getReference();
    private int sa=123;

}
