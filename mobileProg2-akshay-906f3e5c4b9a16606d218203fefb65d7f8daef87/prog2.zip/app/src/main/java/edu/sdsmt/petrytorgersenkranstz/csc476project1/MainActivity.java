package edu.sdsmt.petrytorgersenkranstz.csc476project1;

import android.app.Dialog;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

/**
 *   Authors: Kenneth Petry, Leif Torgersen, and Samantha Kranstz
 *   Mobile Computing
 *   Dr. Lisa Rebenitsch
 *   Project 1
 *   Due Date: October 5, 2017
 *
 *   This file contains the code for creating the main
 *   activity or Welcome page to our project. The
 *   welcome page contains a title, our logo, and a begin
 *   button that leads to the Setup activity.
 */
public class MainActivity extends AppCompatActivity
{
    private static FirebaseUser firebaseUser;
    private FirebaseAuth userAuth = FirebaseAuth.getInstance();
    private static String email="";
    private static String pass="";
    DatabaseReference user=FirebaseDatabase.getInstance().getReference().child("Users");



    @Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
        final Button button = (Button)findViewById(R.id.loginID);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                signIn(v);
                }
        });

    }

	public void onClick(View v) {
        setContentView(R.layout.create_user);
	}

	public void onCreateClick(View v) {
        EditText emailtxt= (EditText)findViewById(R.id.createuserID);
        email=emailtxt.getText().toString();
        EditText passtxt= (EditText)findViewById(R.id.enterPassID);
        pass=passtxt.getText().toString();
        if(isValid()==true) {
            userAuth.createUserWithEmailAndPassword(email, pass)
                    .addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                            String str = firebaseUser.getUid();
                            if (task.isSuccessful() || firebaseUser != null) {
                                HashMap<String, Object> result = new HashMap<>();
                                result.put("id", str);
                                result.put("password", pass);
                                result.put("email", email);
                                user.child(str).setValue(result);
                                setContentView(R.layout.activity_main);
                            } else {

                            }
                        }

                    });

        }
        else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Please make sure the entered data is valid");
            builder.show();
        }

	}

	public void signIn(View v)
    {
        EditText emailtxt= (EditText)findViewById(R.id.userID);
        email=emailtxt.getText().toString();
        EditText passtxt= (EditText)findViewById(R.id.passID);
        pass=passtxt.getText().toString();
        if(isValid()==true) {
            userAuth.signInWithEmailAndPassword(email, pass)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {

                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                setContentView(R.layout.wait);

                            } else {
                            }
                        }
                    });
        }
        else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Please make sure the entered data is valid");
            builder.show();
        }
        }

    public void waitBack(View v) {
        setContentView(R.layout.activity_main);
    }

    public Boolean isValid()
    {
        Boolean valid=true;
        if(pass.length()<6)
            valid=false;
        if(email==null || email.isEmpty() || pass==null || pass.isEmpty())
            valid=false;
        return valid;
    }

}
