package edu.sdsmt.petrytorgersenkranstz.csc476project1;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;

/**
 *  This file gives the user the capture options for
 *  the following round. The options are dot capture,
 *  line capture, and rectangle capture. This activity
 *  also provides a help button that describes each
 *  capture options and their probabilities in capturing.
 *  The next button on this activity leads to the board
 *  activity.
 */
public class RoundOptions extends AppCompatActivity
{
    /**
     *  Holds the first player's name
     */
    private String player1Name;

    /**
     *  Holds the second player's name
     */
    private String player2Name;

    /**
     *   Contains the current player
     *   Or which player has the turn
     */
    private int currentPlayer;

    /**
     *  Holds the remaining number of rounds
     */
    private int roundsLeft;

    /**
     *  Text box displaying the current player
     */
    private TextView player;

    /**
     *  Text box displaying the remaining number of rounds
     */
    private TextView rounds;

    /**
     *  Create Activity
     *  Check to see if text boxes are null
     *  If so, then set them to the corresponding
     *  text boxes' ids in the activity
     *  then set the correct values to be displayed
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_round_options);

        if (player == null)
        {
            player = (TextView) this.findViewById(R.id.playerName);
        }

        if (rounds == null)
        {
            rounds = (TextView) this.findViewById(R.id.roundsLeft);
        }

        player1Name = this.getIntent().getStringExtra(constants.player1Name);
        player2Name = this.getIntent().getStringExtra(constants.player2Name);
        currentPlayer = this.getIntent().getIntExtra(constants.currentPlayer, -1);

        if(currentPlayer == constants.player1)
        {
            player.setText(player1Name);
        }
        else if (currentPlayer == constants.player2)
        {
            player.setText(player2Name);
        }

        roundsLeft = this.getIntent().getIntExtra(constants.roundsLeft, -1);
        if (roundsLeft > 0)
        {
            String temp = Integer.toString(roundsLeft);
            rounds.setText(temp);
        }
    }

    /**
     *  Clicking the next button will move to the Board Activity
     *  Before moving on, carry over and/or update the values of
     *  the players names, the current player, the remaining rounds,
     *  and which capture option was selected.
     *
     * @param view
     */
    public void onBoard(View view)
    {
        Intent intent = new Intent(this, Board.class);

        intent.putExtra(constants.player1Name, player1Name);
        intent.putExtra(constants.player2Name, player2Name);
        intent.putExtra(constants.currentPlayer, currentPlayer);

        intent.putExtra(constants.roundsLeft, Integer.parseInt(rounds.getText().toString()));

        int opt;
        RadioGroup options = (RadioGroup) this.findViewById(R.id.gameOptions);
        int optionId = options.getCheckedRadioButtonId();

        if (optionId == R.id.dotCapture)
        {
            opt = constants.dotSelected;
        }
        else if (optionId == R.id.boxCapture)
        {
            opt = constants.boxSelected;
        }
        else
        {
            opt = constants.lineSelected;
        }

        intent.putExtra(constants.captureOption, opt);

        finish();
        startActivity(intent);
    }

    /**
     *  Clicking the help button pops up an alert box
     *  The dialog in the alert box describes the different
     *  capture options and gives their probabilities
     *
     * @param view
     */
    public void onHelp(View view)
    {
        // Instantiate a dialog box builder
        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());

        // Parameterize the builder
        builder.setTitle(R.string.helpTitle);
        builder.setMessage(R.string.helpMessage);
        builder.setPositiveButton(android.R.string.ok, null);

        // Create the dialog box and show it
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    /**
     *  This function overrides the back button,
     *  Pressing the back button will return to
     *  the Setup Activity
     */
    @Override
    public void onBackPressed()
    {
        finish();
        Intent intent = new Intent(this, Setup.class);
        startActivity(intent);
    }
}
